# Development

To start the environment, execute:

$ docker-compose up -d

This starts both the Git SSH Server, as well as the Webapp.
The app is runnint at http://localhost:8082.

Copy your public SSH key in the ./git-server/keys directory. 
See https://github.com/jkarlosb/git-server-docker for more info on using the Git Server container.

